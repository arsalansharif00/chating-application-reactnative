import React,{ useState, useEffect } from "react";
import {View,Text} from "react-native";
import {useSelector } from 'react-redux';
import { getChat,messageInChatRoom} from "../../config/firebase";

import { doc, onSnapshot, getFirestore } from "firebase/firestore";
import {
    Input,
    Icon,
    Button,
    NativeBaseProvider,
    Center,
    FlatList,
    Box,
    VStack,
    Pressable,
    AlertDialog
  } from "native-base";
 import { addMessage } from "../../config/firebase";
 
 import { GiftedChat } from 'react-native-gifted-chat'
 const db = getFirestore();

export default function Message({route,navigation})
{
    
  const [value,setValue] = useState();
  const [received,setReceived] = useState();
  const [sent,setSent] = useState();
  const [final,setFinal] = useState();
  
  const {item} = route.params;
  // const receiverid = item.id;
  const {id} = useSelector(state => state.userReducer.user);
  console.log(item);



 
  const message = async() =>{
  
    // await addMessage(value,id,receiverid,id);
    await messageInChatRoom(value,item.id,id)
     
  }
  const handle = (text) => {
    setValue(text);
    
    
  };
    useEffect(async() => {
       onSnapshot(
          doc(db, "chatroom",item.id),
          { includeMetadataChanges: true },
          (doc) => {
  
          // let s = doc.data();
          let {messages}=doc.data()
           messages.sort(function(x, y){
                    return x.timestamp - y.timestamp;
           })
          console.log("i am aranged",messages);
          setFinal(messages)
          }
          );

    }, []);


    return(
        <NativeBaseProvider>
        {final && (
          <FlatList
            data={final}
            renderItem={({ item }) => (
              <Pressable>
                {({ isHovered, isFocused, isPressed }) => {
                  return (
                    <Box
                      borderBottomWidth="1"
                      _dark={{
                        borderColor: "gray.600",
                      }}
                      borderColor="coolGray.200"
                      pl="4"
                      pr="5"
                      py="2"
                      ml={item["id"] === id ? "260":0}
                      bg="primary.400"
                      rounded="md"
                      width="50%"
                    >
                      <VStack>
                        <Text
                          _dark={{
                            color: "warmGray.50",
                          }}
                          color="coolGray.800"
                          bold
                        >
                          {item.text}
                        </Text>
                        <Text
                  color="coolGray.600"
                  _dark={{
                    color: "warmGray.200",
                  }}
                >
                {console.log((item.timestamp).toDate())}
                {((item.timestamp).toDate()).toString()}
                </Text>
                       
                      </VStack>
                    </Box>
                  );
                }}
              </Pressable>
            )}
            keyExtractor={(item) => item.senderid}
            width="100%"
          />
        )}
       
        <Input
        size="xl"
        h="60px"
        mb="7"
        isFullWidth={true}
        onChangeText={handle}
        InputRightElement={
          <Button
            size="md"
            rounded="none"
            w="1/4"
            h="full"
            bg="black"
           
            onPress={message}
          >
            send
          </Button> 
        }
      
      />
    
      </NativeBaseProvider>
);
}

